# Submission kit

## 1. Checklist
1. Create a GitHub repo, e.g. `summit-updates`, and upload `index.html`, `README.md` and the `tests/` folder.
2. Open `index.html` once and run through the demo script below.
3. Record the demo (Loom or unlisted YouTube), 3 to 4 minutes, using a phone-width browser window for the employee part.
4. Reply to the original email with the repo link, the video link and the confirmation line.

## 2. Demo script (about 4 minutes)

**0:00 – What I built and who it's for (30s)**
"Hi, I'm [Name]. I picked Scenario 2, important employee updates. I built a small web app for Summit Retail Group. Managers like Michael and Rachel post updates, and sales associates like Alex read them on their phones. The goal is that managers know who has seen what, without Alex getting nagged.
The key decision: **confirmation is opt-in per update.** Most updates are quiet FYIs. Only important ones ask for a one-tap confirmation. That is how I handled Rachel needing proof and Alex wanting no interruptions."

**0:30 – Walkthrough: manager posts (60s)**
*(Click "Ops manager")*
"I'm Michael. The dashboard opens on 'Needs follow-up', so the first thing I see is what needs attention. Let me post an update."
*(Click Post an update. Title: "Dock B closed Tuesday". Message: "Use Dock A for deliveries. Ask your manager if unsure." Pick Harbor and Lakeview.)*
"I choose the stores, and turn on 'Ask employees to confirm' because this is a safety item. The preview shows exactly what staff will see, and the button tells me how many people will get it."
*(Pick "Tomorrow". Click Post.)*

**1:30 – Walkthrough: employee confirms (60s)**
*(Click "Employee", choose a Harbor person)*
"Now I'm a Harbor associate on a phone. The To do tab has a badge and one clear item. I read it and tap 'I've read this'. The button changes to Confirmed, and there's an Undo in case of a mis-tap. A few seconds later the item moves out of To do and the badge clears.
Other updates are quiet. 'Read more' marks them read, and there are no prompts."
*(Switch to the "All updates" tab, then back to an employee with nothing pending to show 'You're all caught up'.)*

**2:30 – Walkthrough: manager follows up (45s)**
*(Click "Store manager", filter Needs follow-up, open See people)*
"Now I'm Rachel. I see who hasn't confirmed, and whether they haven't opened it or opened it but not confirmed. I can remind one person or everyone outstanding. Michael sees the same thing across all stores, with a per-store breakdown."
*(Click Remind all, then briefly show the reminder banner on an employee's card.)*

**3:15 – What I guessed (30s)**
"The request was incomplete, so I assumed: store managers post only to their own store; 'important' is chosen by the manager; confirming means 'I've read this', not 'I agree'; each employee is in one store; and reminders are simulated.
For testing, I checked blank inputs, HTML in text, empty states, store scoping, and ran an automated check of 22 scenarios. Reviewing the AI's work also caught a bug where reading an FYI made it disappear from To do. I fixed it."

**3:45 – What I left out and what I'd ask next (30s)**
"I left out comments and questions, real push or text notifications, editing posted updates, audit export, finer targeting like role or shift, and real login. Next I'd ask Michael: do floor staff have work phones or is text the real channel? Should editing an update reset confirmations? Do safety updates need a compliance record? And who should answer employee questions? Thanks for watching."

## 3. One-line confirmation (paste into your reply)
I confirm I used AI coding tools (Claude) to build this prototype, spent about 3 hours on it, and am sending a Git repo with a README and a 2 to 5 minute demo video as requested.

## 4. Reply email

Subject: APM Take-Home – Summit Updates prototype ([Your name])

Hi [Name],

Here's my take-home submission for Scenario 2 (Important Employee Updates):

- Prototype: [GitHub link] (README explains how to run it; it's a single HTML file, no install)
- Demo video: [Loom link]

I confirm I used AI coding tools (Claude) to build this prototype, spent about 3 hours on it, and am sending a Git repo with a README and a 2 to 5 minute demo video as requested.

The one design decision I'd highlight: confirmation is opt-in per update, so managers get proof on important items while associates aren't interrupted by everything else.

Thanks for your time,
[Your name]
